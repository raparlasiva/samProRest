<?php
require_once('Session.php');
require_once('../includes/DBFuncts.php');

//Grab Meeting id from query string if it exists. It exists after Adding a meeting.

if ( !isset($HTTP_GET_VARS['MID']) || strlen(trim($HTTP_GET_VARS['MID'])) == 0 )
{
	$intQSMeetId = -13;  //bogus id.
}
else
{
	$intQSMeetId = trim($HTTP_GET_VARS['MID']);
}

$conn = db_connect();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>AA Admin</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="LouAAStyles.css" rel="stylesheet" type="text/css">
<SCRIPT SRC="stuff.js" TYPE="text/javascript"></SCRIPT>
</head>
<body>
  <br>
  <table width="50%"  border="0" align="center" cellpadding="1" cellspacing="0">
    <tr>
      <td bgcolor="#7A8E85" class="WhiteTblHeading">&nbsp;<B>indyaa.org Admin</B> </td>
    </tr>
    <tr>
      <td bgcolor="#7A8E85"><table width="100%"  border="0" cellpadding="1" cellspacing="1" bgcolor="#FFFFFF">
          <tr>
            <td colspan="3">&nbsp;</td>
          </tr>
		  <FORM name="form1" method="post" action="EditMeet.php">
          <tr valign="bottom">
            <td colspan="3" class="FormFieldsSearch"><strong>Add Meeting:&nbsp;&nbsp;
              <input type="button" name="Submit2" value="Add" onClick="javascript:location.href='AddMeet.php';">
            </strong></td>
          </tr>
          <tr>
            <td colspan="3">&nbsp;</td>
          </tr>
          <tr>
            <td colspan="3"><span class="FormFieldsSearch"><strong>Edit Meetings:</strong></span></td>
          </tr>
          <tr>
            <td width="22%" valign="top" nowrap class="FormFieldsSearch"><strong>              <strong>
              <select name="selMeetId" size="15" class="SelectMult">
                <?php
				
					$result = mysql_query("SELECT MeetingId, MeetingName, days.Day, 
													LEFT(TIME_FORMAT(MeetTime,'%r'),2) AS MyHour, 
													TIME_FORMAT(MeetTime,'%i') AS MyMinutes, 
													RIGHT(TIME_FORMAT(MeetTime,'%r'),2) AS MyAmOrPM, 
													blnHide
											FROM meetings inner join days
											                  ON meetings.DayId = days.DayId
											WHERE blnHide = 0 AND blnConfirmed = 1
											Order By days.DayId, MeetTime, MeetingName");
					
					for ($i = 0; $i < mysql_num_rows($result); $i++)
					{
						$row = mysql_fetch_array($result);
						
						echo "<OPTION VALUE='".$row['MeetingId']."'";
						
						if ( $i == 0 || $intQSMeetId == $row['MeetingId'])
						{
							echo " SELECTED";
						}
						
						echo ">".$row['Day']." ".$row['MyHour'].":".$row['MyMinutes']." ".$row['MyAmOrPM']." - \"".stripslashes($row['MeetingName'])."\"</OPTION>";
					}
				?>
              </select>
            </strong>            </strong></td>
            <td width="78%" colspan="2" valign="top" class="FormFieldsSearch"><strong>
			  
            </strong>              <input type="submit" name="Submit" value="Edit">
			  <BR>			  <BR>			  <input type="button" value="Delete" onClick="javascript:DeleteMeet(this.form)"></td>
            </tr>
		  </FORM>
          <tr>
            <td colspan="3">&nbsp;</td>
          </tr>
          <tr>
            <td colspan="3">&nbsp;</td>
          </tr>
		 
      </table></td>
	  <TR>
      <td bgcolor="#7A8E85" class="WhiteTblHeading">&nbsp;<?php echo "<B>Total Meetings = ".mysql_num_rows($result)."</B>"; ?></td>
    </tr>
  <TR>
      <td ><a href="Logout.php">Click here to log out.</a></td>
    </tr>
  </table>
<br>  

</body>
</html>
