<?php
require_once('../includes/DBFuncts.php');
require_once('../includes/Constants.php');

//create short variable names
$strMeetName = $HTTP_POST_VARS['txtMeetName'];
$intDayId = $HTTP_POST_VARS['selDayId'];
$intHour = $HTTP_POST_VARS['selHour'];
$intMinute = $HTTP_POST_VARS['selMinute'];
$strAMorPM = $HTTP_POST_VARS['selAMOrPM'];
$strBuildName = $HTTP_POST_VARS['txtBuildName'];
$strAddress = $HTTP_POST_VARS['txtAddress'];
$strArea = $HTTP_POST_VARS['txtArea'];
$intZip = $HTTP_POST_VARS['txtZip'];
$strSpcNotes = $HTTP_POST_VARS['txtSpcNotes'];
$intOpenOrClosed = $HTTP_POST_VARS['rdoOpenOrClosed'];
$intMeetTypes = $HTTP_POST_VARS['selMeetTypes'];

//Is Viewable is hidden on the simple Admin, so never hide the meeting.
$blnHide = 0;

$str24HrTime = Convert12hrTo24hr($strAMorPM, $intHour, $intMinute);

// connect to db
$conn = db_connect();

if (!$conn)
{
	return 'no conn';
}

$strMeetName = addslashes(TRIM($strMeetName));
$strAddress = addslashes(TRIM($strAddress));

if ( !empty($strBuildName)  )
{
	$strBuildName = addslashes(TRIM($strBuildName));
}
else
{
	$strBuildName = "N/A";
}

if ( !empty($strArea)  )
{
	$strArea = addslashes(TRIM($strArea));
}
else
{
	$strArea = "N/A";
}

if ( !empty($strSpcNotes)  )
{
	$strSpcNotes = addslashes(TRIM($strSpcNotes));
}
else
{
	$strSpcNotes = "N/A";
}

if ( !empty($intZip)  )
{
	$intZip = (int)(TRIM($intZip));
}
else
{
	$intZip = 0;
}

$query = "INSERT INTO meetings
				(MeetingName, DayId, MeetTime, BuildingName, Address, Area, Zip, blnHide, SpecialNotes) 
			VALUES
				('".$strMeetName."', ".$intDayId.", '".$str24HrTime."', '".$strBuildName."', 
					 '".$strAddress."', '".$strArea."', ".$intZip.",".$blnHide.",'".$strSpcNotes."')";

$result = mysql_query($query);

if (!$result)
{
	return 'no results';
}
else
{
	$intMeetingId = mysql_insert_id();
	
	//First, insert the Closed or Open Meeting Type, ask this seperately because
	//any meeting must be either open or closed.
	
	$query = "INSERT INTO meetings_meetingtypes
					(MeetingId, TypeId) 
				VALUES
					(".$intMeetingId.", ".$intOpenOrClosed.")";
	
	$result = mysql_query($query);
	
	//Next, Looped de doop for each remaining meeting type selected.
	
    foreach ($HTTP_POST_VARS['selMeetTypes'] as $intMeetType)
    {
		$query = "INSERT INTO meetings_meetingtypes
						(MeetingId, TypeId) 
					VALUES
						(".$intMeetingId.", ".$intMeetType.")";
		
		$result = mysql_query($query);
    }
}

//Send back to Admin Home Page.

header('Location: index.php?MID='.$intMeetingId);

//All functions below:

function Convert12hrTo24hr($strAMOrPM, $intHour, $intMinute)
{
	/*
	To convert from 12-hour time to 24-hour time:
	
	  A. If the P.M. hour is from 1 through 11, add 12.
	
	  B. If the P.M. hour is 12, leave it as is.
	
	  C. If the A.M. hour is 12, make it 0.
	
	  D. Otherwise, leave the hour unchanged.
	
	  Then drop the A.M. or P.M., of course.
	*/
	if ($strAMOrPM == "PM")
	{
		if ($intHour != 12)
		{
			$intHour = (int)$intHour + 12;
		}
	}
	else
	{
		if ($intHour == 12)
		{
			$intHour = 0;
		}
	}
	
	return $intHour.":".$intMinute;
}
?>